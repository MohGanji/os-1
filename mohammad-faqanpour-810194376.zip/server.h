#ifndef __SERVER__
#define __SERVER__

void main_server(char* PORT);
void data_server(char* PORT, char *shared_dir);

#endif