#ifndef __CLIENT_CONNECT__
#define __CLIENT_CONNECT__


#include "utils.h"

int client_connect(char* ip, char* port, int *sock);

#endif